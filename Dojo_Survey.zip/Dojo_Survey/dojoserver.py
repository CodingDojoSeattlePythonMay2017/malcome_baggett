from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")
@app.route("/results", methods=["POST"])
def results():


    return render_template("process.html", Name=request.form["name"], Dojo_Location=request.form["Dojo Location"], Favorite_Language=request.form["Favorite Language"], Comments=request.form["Comments"] )

@app.route("/back", methods=["POST"])
def back():
    return redirect("/")
app.run(debug=True)


